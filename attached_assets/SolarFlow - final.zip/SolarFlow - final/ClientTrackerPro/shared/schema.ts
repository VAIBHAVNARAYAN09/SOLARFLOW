import { pgTable, text, serial, integer, boolean, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  role: text("role").notNull().default("user"),
  avatar: text("avatar"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  avatar: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Ticket status enum
export const ticketStatusEnum = pgEnum("ticket_status", [
  "open", 
  "assigned", 
  "in_progress", 
  "waiting", 
  "resolved", 
  "closed"
]);

// Ticket priority enum
export const ticketPriorityEnum = pgEnum("ticket_priority", [
  "low", 
  "medium", 
  "high"
]);

// Tickets schema
export const tickets = pgTable("tickets", {
  id: serial("id").primaryKey(),
  subject: text("subject").notNull(),
  description: text("description").notNull(),
  status: ticketStatusEnum("status").notNull().default("open"),
  priority: ticketPriorityEnum("priority").notNull(),
  userId: integer("user_id").notNull(),
  assignedToId: integer("assigned_to_id"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertTicketSchema = createInsertSchema(tickets).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  assignedToId: true,
});

export type InsertTicket = z.infer<typeof insertTicketSchema>;
export type Ticket = typeof tickets.$inferSelect;

// SolarPanel schema
export const solarPanels = pgTable("solar_panels", {
  id: serial("id").primaryKey(),
  siteId: text("site_id").notNull(),
  location: text("location").notNull(),
  capacity: text("capacity").notNull(),
  userId: integer("user_id").notNull(),
  installationDate: timestamp("installation_date").notNull(),
  status: text("status").notNull().default("operational"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertSolarPanelSchema = createInsertSchema(solarPanels).omit({
  id: true,
  createdAt: true,
});

export type InsertSolarPanel = z.infer<typeof insertSolarPanelSchema>;
export type SolarPanel = typeof solarPanels.$inferSelect;

// Performance data schema
export const performanceData = pgTable("performance_data", {
  id: serial("id").primaryKey(),
  solarPanelId: integer("solar_panel_id").notNull(),
  output: text("output").notNull(),
  performanceRatio: text("performance_ratio").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertPerformanceDataSchema = createInsertSchema(performanceData).omit({
  id: true,
});

export type InsertPerformanceData = z.infer<typeof insertPerformanceDataSchema>;
export type PerformanceData = typeof performanceData.$inferSelect;

// Maintenance reports schema
export const maintenanceReports = pgTable("maintenance_reports", {
  id: serial("id").primaryKey(),
  solarPanelId: integer("solar_panel_id").notNull(),
  technician: text("technician").notNull(),
  report: text("report").notNull(),
  serviceDate: timestamp("service_date").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertMaintenanceReportSchema = createInsertSchema(maintenanceReports).omit({
  id: true,
  createdAt: true,
});

export type InsertMaintenanceReport = z.infer<typeof insertMaintenanceReportSchema>;
export type MaintenanceReport = typeof maintenanceReports.$inferSelect;

// Referrals schema
export const referrals = pgTable("referrals", {
  id: serial("id").primaryKey(),
  referrerId: integer("referrer_id").notNull(),
  referredName: text("referred_name").notNull(),
  referredEmail: text("referred_email").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertReferralSchema = createInsertSchema(referrals).omit({
  id: true,
  createdAt: true,
});

export type InsertReferral = z.infer<typeof insertReferralSchema>;
export type Referral = typeof referrals.$inferSelect;

// Maintenance bookings schema
export const maintenanceBookings = pgTable("maintenance_bookings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  solarPanelId: integer("solar_panel_id").notNull(),
  requestedDate: timestamp("requested_date").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull().default("pending"),
  paymentStatus: text("payment_status").notNull().default("unpaid"),
  amount: text("amount").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertMaintenanceBookingSchema = createInsertSchema(maintenanceBookings).omit({
  id: true,
  createdAt: true,
});

export type InsertMaintenanceBooking = z.infer<typeof insertMaintenanceBookingSchema>;
export type MaintenanceBooking = typeof maintenanceBookings.$inferSelect;
