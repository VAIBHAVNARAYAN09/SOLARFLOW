import { users, type User, type InsertUser, 
         tickets, type Ticket, type InsertTicket,
         solarPanels, type SolarPanel, type InsertSolarPanel,
         performanceData, type PerformanceData, type InsertPerformanceData,
         maintenanceReports, type MaintenanceReport, type InsertMaintenanceReport,
         referrals, type Referral, type InsertReferral,
         maintenanceBookings, type MaintenanceBooking, type InsertMaintenanceBooking } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Ticket operations
  getTicket(id: number): Promise<Ticket | undefined>;
  getAllTickets(): Promise<Ticket[]>;
  getTicketsByUserId(userId: number): Promise<Ticket[]>;
  createTicket(ticket: InsertTicket): Promise<Ticket>;
  updateTicket(id: number, updates: Partial<Ticket>): Promise<Ticket>;
  
  // Solar Panel operations
  getSolarPanel(id: number): Promise<SolarPanel | undefined>;
  getAllSolarPanels(): Promise<SolarPanel[]>;
  getSolarPanelsByUserId(userId: number): Promise<SolarPanel[]>;
  createSolarPanel(panel: InsertSolarPanel): Promise<SolarPanel>;
  
  // Performance Data operations
  getAllPerformanceData(daysBack?: number): Promise<PerformanceData[]>;
  getPerformanceDataByPanelId(panelId: number, daysBack?: number): Promise<PerformanceData[]>;
  getPerformanceDataByUserId(userId: number, daysBack?: number): Promise<PerformanceData[]>;
  createPerformanceData(data: InsertPerformanceData): Promise<PerformanceData>;
  
  // Maintenance Report operations
  getAllMaintenanceReports(): Promise<MaintenanceReport[]>;
  getMaintenanceReportsByUserId(userId: number): Promise<MaintenanceReport[]>;
  createMaintenanceReport(report: InsertMaintenanceReport): Promise<MaintenanceReport>;
  
  // Referral operations
  getAllReferrals(): Promise<Referral[]>;
  getReferralsByUserId(userId: number): Promise<Referral[]>;
  createReferral(referral: InsertReferral): Promise<Referral>;
  
  // Maintenance booking operations
  getAllMaintenanceBookings(): Promise<MaintenanceBooking[]>;
  getMaintenanceBookingsByUserId(userId: number): Promise<MaintenanceBooking[]>;
  createMaintenanceBooking(booking: InsertMaintenanceBooking): Promise<MaintenanceBooking>;
  updateMaintenanceBookingStatus(id: number, status: string): Promise<MaintenanceBooking>;
  updateMaintenanceBookingPaymentStatus(id: number, paymentStatus: string): Promise<MaintenanceBooking>;
  
  // Session store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private usersStore: Map<number, User>;
  private ticketsStore: Map<number, Ticket>;
  private solarPanelsStore: Map<number, SolarPanel>;
  private performanceDataStore: Map<number, PerformanceData>;
  private maintenanceReportsStore: Map<number, MaintenanceReport>;
  private referralsStore: Map<number, Referral>;
  private maintenanceBookingsStore: Map<number, MaintenanceBooking>;
  
  sessionStore: any; // Use any to avoid type errors with session store
  
  private userIdCounter: number;
  private ticketIdCounter: number;
  private solarPanelIdCounter: number;
  private performanceDataIdCounter: number;
  private maintenanceReportIdCounter: number;
  private referralIdCounter: number;
  private maintenanceBookingIdCounter: number;

  constructor() {
    this.usersStore = new Map();
    this.ticketsStore = new Map();
    this.solarPanelsStore = new Map();
    this.performanceDataStore = new Map();
    this.maintenanceReportsStore = new Map();
    this.referralsStore = new Map();
    this.maintenanceBookingsStore = new Map();
    
    this.userIdCounter = 1;
    this.ticketIdCounter = 1;
    this.solarPanelIdCounter = 1;
    this.performanceDataIdCounter = 1;
    this.maintenanceReportIdCounter = 1;
    this.referralIdCounter = 1;
    this.maintenanceBookingIdCounter = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // Prune expired entries every 24h
    });
    
    // Add an admin user by default
    this.createUser({
      username: "admin",
      password: "0e2aaad8ff9950c033b9a56e6049fb33b0a4a2c5e65b3dfdde14b93ea94ba9f22e6d3abce2b89c73088b148a54c3f6a9ac6aa4158c5f0a58e02c12622deefd79.c6a3ff8443c9bed2",
      name: "Admin User",
      email: "admin@auits.com",
      role: "admin"
    });
  }

  // User Methods
  async getUser(id: number): Promise<User | undefined> {
    return this.usersStore.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    for (const user of this.usersStore.values()) {
      if (user.username === username) {
        return user;
      }
    }
    return undefined;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = {
      ...userData,
      id,
      avatar: userData.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(userData.name)}&background=random`,
      createdAt: now
    };
    this.usersStore.set(id, user);
    return user;
  }

  // Ticket Methods
  async getTicket(id: number): Promise<Ticket | undefined> {
    return this.ticketsStore.get(id);
  }

  async getAllTickets(): Promise<Ticket[]> {
    return Array.from(this.ticketsStore.values());
  }

  async getTicketsByUserId(userId: number): Promise<Ticket[]> {
    return Array.from(this.ticketsStore.values()).filter(
      ticket => ticket.userId === userId
    );
  }

  async createTicket(ticketData: InsertTicket): Promise<Ticket> {
    const id = this.ticketIdCounter++;
    const now = new Date();
    const ticket: Ticket = {
      ...ticketData,
      id,
      assignedToId: null,
      createdAt: now,
      updatedAt: now
    };
    this.ticketsStore.set(id, ticket);
    return ticket;
  }

  async updateTicket(id: number, updates: Partial<Ticket>): Promise<Ticket> {
    const ticket = this.ticketsStore.get(id);
    
    if (!ticket) {
      throw new Error(`Ticket with ID ${id} not found`);
    }
    
    const updatedTicket: Ticket = {
      ...ticket,
      ...updates,
      updatedAt: new Date()
    };
    
    this.ticketsStore.set(id, updatedTicket);
    return updatedTicket;
  }

  // Solar Panel Methods
  async getSolarPanel(id: number): Promise<SolarPanel | undefined> {
    return this.solarPanelsStore.get(id);
  }

  async getAllSolarPanels(): Promise<SolarPanel[]> {
    return Array.from(this.solarPanelsStore.values());
  }

  async getSolarPanelsByUserId(userId: number): Promise<SolarPanel[]> {
    return Array.from(this.solarPanelsStore.values()).filter(
      panel => panel.userId === userId
    );
  }

  async createSolarPanel(panelData: InsertSolarPanel): Promise<SolarPanel> {
    const id = this.solarPanelIdCounter++;
    const now = new Date();
    const panel: SolarPanel = {
      ...panelData,
      id,
      createdAt: now
    };
    this.solarPanelsStore.set(id, panel);
    return panel;
  }

  // Performance Data Methods
  async getAllPerformanceData(daysBack: number = 1): Promise<PerformanceData[]> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysBack);
    
    return Array.from(this.performanceDataStore.values()).filter(
      data => data.timestamp >= cutoffDate
    );
  }

  async getPerformanceDataByPanelId(panelId: number, daysBack: number = 1): Promise<PerformanceData[]> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysBack);
    
    return Array.from(this.performanceDataStore.values()).filter(
      data => data.solarPanelId === panelId && data.timestamp >= cutoffDate
    );
  }

  async getPerformanceDataByUserId(userId: number, daysBack: number = 1): Promise<PerformanceData[]> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysBack);
    
    // Get all panels for this user
    const userPanels = await this.getSolarPanelsByUserId(userId);
    const panelIds = userPanels.map(panel => panel.id);
    
    // Get performance data for these panels
    return Array.from(this.performanceDataStore.values()).filter(
      data => panelIds.includes(data.solarPanelId) && data.timestamp >= cutoffDate
    );
  }

  async createPerformanceData(data: InsertPerformanceData): Promise<PerformanceData> {
    const id = this.performanceDataIdCounter++;
    const performanceData: PerformanceData = {
      ...data,
      id
    };
    this.performanceDataStore.set(id, performanceData);
    return performanceData;
  }

  // Maintenance Report Methods
  async getAllMaintenanceReports(): Promise<MaintenanceReport[]> {
    return Array.from(this.maintenanceReportsStore.values());
  }

  async getMaintenanceReportsByUserId(userId: number): Promise<MaintenanceReport[]> {
    // Get all panels for this user
    const userPanels = await this.getSolarPanelsByUserId(userId);
    const panelIds = userPanels.map(panel => panel.id);
    
    // Get maintenance reports for these panels
    return Array.from(this.maintenanceReportsStore.values()).filter(
      report => panelIds.includes(report.solarPanelId)
    );
  }

  async createMaintenanceReport(reportData: InsertMaintenanceReport): Promise<MaintenanceReport> {
    const id = this.maintenanceReportIdCounter++;
    const now = new Date();
    const report: MaintenanceReport = {
      ...reportData,
      id,
      createdAt: now
    };
    this.maintenanceReportsStore.set(id, report);
    return report;
  }

  // Referral Methods
  async getAllReferrals(): Promise<Referral[]> {
    return Array.from(this.referralsStore.values());
  }

  async getReferralsByUserId(userId: number): Promise<Referral[]> {
    return Array.from(this.referralsStore.values()).filter(
      referral => referral.referrerId === userId
    );
  }

  async createReferral(referralData: InsertReferral): Promise<Referral> {
    const id = this.referralIdCounter++;
    const now = new Date();
    const referral: Referral = {
      ...referralData,
      id,
      createdAt: now,
      status: referralData.status || "pending"
    };
    this.referralsStore.set(id, referral);
    return referral;
  }

  // Maintenance Booking Methods
  async getAllMaintenanceBookings(): Promise<MaintenanceBooking[]> {
    return Array.from(this.maintenanceBookingsStore.values());
  }

  async getMaintenanceBookingsByUserId(userId: number): Promise<MaintenanceBooking[]> {
    return Array.from(this.maintenanceBookingsStore.values()).filter(
      booking => booking.userId === userId
    );
  }

  async createMaintenanceBooking(bookingData: InsertMaintenanceBooking): Promise<MaintenanceBooking> {
    const id = this.maintenanceBookingIdCounter++;
    const now = new Date();
    const booking: MaintenanceBooking = {
      ...bookingData,
      id,
      createdAt: now,
      status: bookingData.status || "pending",
      paymentStatus: bookingData.paymentStatus || "unpaid"
    };
    this.maintenanceBookingsStore.set(id, booking);
    return booking;
  }

  async updateMaintenanceBookingStatus(id: number, status: string): Promise<MaintenanceBooking> {
    const booking = this.maintenanceBookingsStore.get(id);
    
    if (!booking) {
      throw new Error(`Maintenance booking with ID ${id} not found`);
    }
    
    const updatedBooking: MaintenanceBooking = {
      ...booking,
      status
    };
    
    this.maintenanceBookingsStore.set(id, updatedBooking);
    return updatedBooking;
  }

  async updateMaintenanceBookingPaymentStatus(id: number, paymentStatus: string): Promise<MaintenanceBooking> {
    const booking = this.maintenanceBookingsStore.get(id);
    
    if (!booking) {
      throw new Error(`Maintenance booking with ID ${id} not found`);
    }
    
    const updatedBooking: MaintenanceBooking = {
      ...booking,
      paymentStatus
    };
    
    this.maintenanceBookingsStore.set(id, updatedBooking);
    return updatedBooking;
  }
}

export const storage = new MemStorage();
