import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { z } from "zod";
import { insertTicketSchema, insertSolarPanelSchema, insertPerformanceDataSchema, insertMaintenanceReportSchema, insertReferralSchema, insertMaintenanceBookingSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // Tickets routes
  app.get("/api/tickets", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const userId = req.user?.id;
      const isAdmin = req.user?.role === "admin";
      
      // Admins can see all tickets, users can only see their own
      const tickets = isAdmin 
        ? await storage.getAllTickets()
        : await storage.getTicketsByUserId(userId!);
      
      res.json(tickets);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/tickets/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const ticketId = parseInt(req.params.id);
      const ticket = await storage.getTicket(ticketId);
      
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }
      
      // Check if user is authorized to view this ticket
      if (req.user?.role !== "admin" && ticket.userId !== req.user?.id) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      res.json(ticket);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/tickets", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const validatedData = insertTicketSchema.parse({
        ...req.body,
        userId: req.user?.id,
      });
      
      const ticket = await storage.createTicket(validatedData);
      res.status(201).json(ticket);
    } catch (error) {
      next(error);
    }
  });

  app.patch("/api/tickets/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const ticketId = parseInt(req.params.id);
      const ticket = await storage.getTicket(ticketId);
      
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }
      
      // Only admins can update tickets they don't own
      if (req.user?.role !== "admin" && ticket.userId !== req.user?.id) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const updatedTicket = await storage.updateTicket(ticketId, req.body);
      res.json(updatedTicket);
    } catch (error) {
      next(error);
    }
  });

  // Solar Panels routes
  app.get("/api/solar-panels", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const userId = req.user?.id;
      const isAdmin = req.user?.role === "admin";
      
      const panels = isAdmin 
        ? await storage.getAllSolarPanels()
        : await storage.getSolarPanelsByUserId(userId!);
      
      res.json(panels);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/solar-panels", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      // Only admins can create solar panels
      if (req.user?.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const validatedData = insertSolarPanelSchema.parse(req.body);
      const panel = await storage.createSolarPanel(validatedData);
      res.status(201).json(panel);
    } catch (error) {
      next(error);
    }
  });

  // Performance Data routes
  app.get("/api/performance-data", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const userId = req.user?.id;
      const isAdmin = req.user?.role === "admin";
      
      // Parse optional query parameters for filtering
      const panelId = req.query.panelId ? parseInt(req.query.panelId as string) : undefined;
      const daysBack = req.query.days ? parseInt(req.query.days as string) : 1;
      
      let data;
      if (isAdmin && panelId) {
        data = await storage.getPerformanceDataByPanelId(panelId, daysBack);
      } else if (isAdmin) {
        data = await storage.getAllPerformanceData(daysBack);
      } else {
        data = await storage.getPerformanceDataByUserId(userId!, daysBack);
      }
      
      res.json(data);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/performance-data", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      // Only admins can add performance data
      if (req.user?.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const validatedData = insertPerformanceDataSchema.parse(req.body);
      const data = await storage.createPerformanceData(validatedData);
      res.status(201).json(data);
    } catch (error) {
      next(error);
    }
  });

  // Maintenance Reports routes
  app.get("/api/maintenance-reports", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const userId = req.user?.id;
      const isAdmin = req.user?.role === "admin";
      
      const reports = isAdmin 
        ? await storage.getAllMaintenanceReports()
        : await storage.getMaintenanceReportsByUserId(userId!);
      
      res.json(reports);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/maintenance-reports", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      // Only admins can create maintenance reports
      if (req.user?.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const validatedData = insertMaintenanceReportSchema.parse(req.body);
      const report = await storage.createMaintenanceReport(validatedData);
      res.status(201).json(report);
    } catch (error) {
      next(error);
    }
  });

  // Referrals routes
  app.get("/api/referrals", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const userId = req.user?.id;
      const isAdmin = req.user?.role === "admin";
      
      const referrals = isAdmin 
        ? await storage.getAllReferrals()
        : await storage.getReferralsByUserId(userId!);
      
      res.json(referrals);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/referrals", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const validatedData = insertReferralSchema.parse({
        ...req.body,
        referrerId: req.user?.id,
      });
      
      const referral = await storage.createReferral(validatedData);
      res.status(201).json(referral);
    } catch (error) {
      next(error);
    }
  });

  // Weather forecast API (mock data for now)
  app.get("/api/weather-forecast", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const location = req.query.location || "New Delhi, India";
      
      // In a real application, this would call an external weather API
      const weatherData = {
        location: location,
        current: {
          temperature: 32,
          condition: "Sunny",
          icon: "sun",
          expectedProduction: 85, // percent of max
        },
        forecast: [
          { day: "Mon", condition: "sunny", temperature: 33, productionPercent: 90 },
          { day: "Tue", condition: "cloudy", temperature: 29, productionPercent: 65 },
          { day: "Wed", condition: "rain", temperature: 28, productionPercent: 40 },
          { day: "Thu", condition: "sunny", temperature: 31, productionPercent: 88 },
          { day: "Fri", condition: "partly-cloudy", temperature: 30, productionPercent: 75 }
        ]
      };
      
      res.json(weatherData);
    } catch (error) {
      next(error);
    }
  });

  // Maintenance Booking routes
  app.get("/api/maintenance-bookings", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const userId = req.user?.id;
      const isAdmin = req.user?.role === "admin";
      
      const bookings = isAdmin 
        ? await storage.getAllMaintenanceBookings()
        : await storage.getMaintenanceBookingsByUserId(userId!);
      
      res.json(bookings);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/maintenance-bookings/:id", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const bookingId = parseInt(req.params.id);
      
      // In a real app, there would be a getMaintenanceBooking method
      const bookings = await storage.getAllMaintenanceBookings();
      const booking = bookings.find(b => b.id === bookingId);
      
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      // Check if user is authorized to view this booking
      if (req.user?.role !== "admin" && booking.userId !== req.user?.id) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      res.json(booking);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/maintenance-bookings", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const validatedData = insertMaintenanceBookingSchema.parse({
        ...req.body,
        userId: req.user?.id,
        status: "pending",
        paymentStatus: "unpaid",
        amount: "4500.00" // Default maintenance fee in INR
      });
      
      const booking = await storage.createMaintenanceBooking(validatedData);
      res.status(201).json(booking);
    } catch (error) {
      next(error);
    }
  });

  app.patch("/api/maintenance-bookings/:id/status", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const bookingId = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!status) {
        return res.status(400).json({ message: "Status is required" });
      }
      
      // Only admins can update booking status
      if (req.user?.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const updatedBooking = await storage.updateMaintenanceBookingStatus(bookingId, status);
      res.json(updatedBooking);
    } catch (error) {
      next(error);
    }
  });

  app.patch("/api/maintenance-bookings/:id/payment", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const bookingId = parseInt(req.params.id);
      const { paymentStatus } = req.body;
      
      if (!paymentStatus) {
        return res.status(400).json({ message: "Payment status is required" });
      }
      
      // Get the booking to check ownership
      const bookings = await storage.getAllMaintenanceBookings();
      const booking = bookings.find(b => b.id === bookingId);
      
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      // Check if user is authorized to update this booking
      if (req.user?.role !== "admin" && booking.userId !== req.user?.id) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const updatedBooking = await storage.updateMaintenanceBookingPaymentStatus(bookingId, paymentStatus);
      res.json(updatedBooking);
    } catch (error) {
      next(error);
    }
  });
  
  // Chatbot API endpoint
  app.post("/api/chatbot", async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      
      const { message } = req.body;
      
      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }
      
      // Simple response logic
      let response;
      const lowercaseMessage = message.toLowerCase();
      
      if (lowercaseMessage.includes("panel") && lowercaseMessage.includes("not working")) {
        response = "I'm sorry to hear that your solar panel isn't working. Let's create a support ticket. Please provide the site ID and a description of the issue.";
      } else if (lowercaseMessage.includes("battery") && lowercaseMessage.includes("charging")) {
        response = "Battery charging issues are common. Have you checked if the inverter is working properly? If not, I recommend creating a high priority ticket.";
      } else if (lowercaseMessage.includes("maintenance")) {
        response = "We recommend maintenance checks every 6 months. Would you like to schedule your next maintenance visit? You can now book maintenance services directly through our app.";
      } else if (lowercaseMessage.includes("weather")) {
        response = "You can check the weather forecast and its impact on your solar production in the Weather Forecasts section of the app.";
      } else {
        response = "I'm here to help with any questions about your solar installation. Feel free to ask about panel performance, maintenance, or support.";
      }
      
      res.json({ response });
    } catch (error) {
      next(error);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
